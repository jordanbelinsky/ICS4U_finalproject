import pygame
from shape_class import *
pygame.init()

# General Variables #
gridSize = 100
size = 10
FPS = 100
WIDTH,HEIGHT = 1000,800
generation = 0
count = 0

# Define 2D List for Board #
board = [[False for i in range(gridSize)] for j in range(gridSize)]

# Colors #
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREY = (211, 211, 211)
coolGrey = (130,130,130)
RED = (255,0,0)

# States #
rules = False
rules_2 = False
main_game = True

# Pygame Display Variables #
font = pygame.font.SysFont("Ariel Black", 30)
typeFont = pygame.font.SysFont("Ariel Black", 20)
header = pygame.font.SysFont("Ariel Black", 38) 
screen = pygame.display.set_mode((WIDTH,HEIGHT))                        # define the surface for the simulation to run on
pygame.display.set_caption('Conway\'s Game of Life')
smallglider_text = font.render('Small Glider', False, (0, 0, 0))
smallexploder_text = font.render('Small Exploder', False, (0, 0, 0))
spaceship_text = font.render('Spaceship', False, (0, 0, 0))
tumbler_text = font.render('Tumbler', False, (0, 0, 0))
rules_text = font.render('Rules', False, (0, 0, 0))

# Side Menu Variables # 
extendo = False                                 # side menu starts closed
currentShape = -1 

# Preset Shape Tuples #
smallglider = Shape([[False,True,False],
                     [False,False,True],
                     [True,True,True]])

smallexploder = Shape([[False,True,False],
                       [True,True,True],
                       [True,False,True],
                       [False,True,False]])

spaceship = Shape([[False,True,True,True,True],
                   [True,False,False,False,True],
                   [False,False,False,False,True],
                   [True,False,False,True,False]])

tumbler = Shape([[False,True,True,False,True,True,False],
                 [False,True,True,False,True,True,False],
                 [False,False,True,False,True,False,False],
                 [True,False,True,False,True,False,True],
                 [True,False,True,False,True,False,True],
                 [True,True,False,False,False,True,True]])

# Preset Shape List #       
allShapes = [smallglider, smallexploder, spaceship, tumbler]

# Deactivate a Grid Cell #
def killRuthlessly(row, col):
    board[row][col] = False

# Display GUI Elements on Screen #
def drawGui():
    global extendo

    # Side Menu GUI #
    if extendo == True:
        pygame.draw.rect(screen, coolGrey, (800, 0, 200, HEIGHT), 0)
        pygame.draw.rect(screen, BLACK, (800, 1, 199, HEIGHT-2), 3)
        pygame.draw.rect(screen, WHITE, (820, 50, 160, 80), 0)                                # small glider
        pygame.draw.rect(screen, WHITE, (820, 165, 160, 80), 0)                               # small exploder
        pygame.draw.rect(screen, WHITE, (820, 280, 160, 80), 0)                               # spaceship
        pygame.draw.rect(screen, WHITE, (820, 395, 160, 80), 0)                               # tumbler
        pygame.draw.rect(screen, WHITE, (820, 690, 160, 80), 0)                               # rules
        pygame.draw.rect(screen, BLACK, (777, 402, 24, 86), 0)
        pygame.draw.rect(screen, coolGrey, (780, 405, 19, 80), 0)
        pygame.draw.polygon(screen, WHITE, [(785, 419), (785, 429), (795, 424)], 0)
        pygame.draw.polygon(screen, WHITE, [(785, 439), (785, 449), (795, 444)], 0)
        pygame.draw.polygon(screen, WHITE, [(785, 459), (785, 469), (795, 464)], 0)
        screen.blit(smallglider_text, (820, 25))                                  # small glider
        screen.blit(smallexploder_text, (820, 140))                               # small exploder
        screen.blit(spaceship_text, (820, 255))                                   # spaceship
        screen.blit(tumbler_text, (820, 370))                                     # tumblerr
        screen.blit(rules_text, (870, 720))
        
    # General GUI #
    else:
        pygame.draw.rect(screen, BLACK, (980, 405, 50, 80), 3)
        pygame.draw.rect(screen, coolGrey, (980, 405, 50, 80), 0)
        pygame.draw.polygon(screen, WHITE, [(995, 419), (995, 429), (985, 424)], 0)
        pygame.draw.polygon(screen ,WHITE, [(995, 439), (995, 449), (985, 444)], 0)
        pygame.draw.polygon(screen, WHITE, [(995, 459), (995, 469), (985, 464)], 0)

# Display Text #
def drawText(message,text_X,text_Y):
    text = font.render(message, 1, BLACK)                               # put the font and the message together
    screen.blit(text,(text_X,text_Y))

# Display First Rules Page #
def draw_rules_page_one():
    title = header.render("Conway's Game Of Life", 1, BLACK)
    description_1 = font.render('This is a game where you draw set patterns of squares on the screen,', 1, BLACK)
    description_2 = font.render('which are then animated and react to the rules below, forming a living ecosystem.', 1, BLACK) 
    rule_1 = font.render('1. Any live cell with fewer than two live neighbours dies, as if caused by under-population.', 1, BLACK)
    rule_2 = font.render('2. Any live cell with two or three live neighbours lives on to the next generation.', 1, BLACK)
    rule_3 = font.render('3. Any live cell with more than three live neighbours dies, as if by overcrowding.', 1, BLACK)
    rule_4 = font.render('4. Any dead cell with exactly three live neighbours becomes a live cell, as if by reproduction.', 1, BLACK)
    names = font.render('By: Jordan Belinsky, Ritchie DiMaria, Alex Giannoulis, and Jeremy Weisberg', 1, BLACK)
    escape =  font.render('Press E to return to the main game', 1, BLACK)
    screen.blit(title, (350, 50))
    screen.blit(description_1, (150, 125))
    screen.blit(description_2, (95, 175))
    screen.blit(rule_1, (50, 275))
    screen.blit(rule_2, (100, 340))
    screen.blit(rule_3, (100, 415))
    screen.blit(rule_4, (50, 490))
    screen.blit(names, (105, 585))
    screen.blit(escape, (335, 700))
    pygame.draw.rect(screen, BLACK, (380,750,100,30), 0)
    pygame.draw.rect(screen, coolGrey, (530,750,100,30), 0)

# Display Second Rules Page #
def draw_rules_page_two():
    title = header.render("Conway's Game Of Life", 1, BLACK)
    description_1 = font.render('This is a game where you draw set patterns of squares on the screen,', 1, BLACK)
    description_2 = font.render('which are then animated and react to the rules below, forming a living ecosystem.', 1, BLACK)
    key_title = font.render('Keyboard Shortcuts:', 1, BLACK)
    key_space = font.render('Space: Start/Pause Game', 1, BLACK)
    key_s = font.render('S: Save Map', 1, BLACK)
    key_l = font.render('L: Load Map', 1, BLACK)
    key_f = font.render('F: Enable/Disable Drag Select', 1, BLACK)
    key_k = font.render('K: Load Shape', 1, BLACK)
    key_r = font.render('R: Random Map', 1, BLACK)
    key_c = font.render('C: Clear Map', 1, BLACK)
    key_right = font.render('Right Arrow: Fast Forward', 1, BLACK)
    escape =  font.render('Press E to return to the main game', 1, BLACK)
    screen.blit(title, (350, 50))
    screen.blit(description_1, (150, 125))
    screen.blit(description_2, (95, 175))
    screen.blit(key_title, (400, 275))
    screen.blit(key_space, (380, 320))
    screen.blit(key_s, (440, 355))
    screen.blit(key_l, (440, 390))
    screen.blit(key_f, (355, 425))
    screen.blit(key_k, (435, 460))
    screen.blit(key_r, (435, 495))
    screen.blit(key_c, (440, 530))
    screen.blit(key_right, (375, 565))
    screen.blit(escape, (335, 700))
    pygame.draw.rect(screen, coolGrey, (380,750,100,30), 0)
    pygame.draw.rect(screen, BLACK, (530,750,100,30), 0)
