import pygame
pygame.init()
gridSize = 100
coolGrey = (130,130,130)
WIDTH,HEIGHT = 1000,800
board = [[False for i in range(gridSize)] for j in range(gridSize)]
screen = pygame.display.set_mode((WIDTH,HEIGHT))   

# Preset Shape Preview #
def drawTempRect(row,col):
    pygame.draw.rect(screen, coolGrey, (row*10, col*10, 10, 10), 0)

# Preset Shape Class #
class Shape(object):
    def __init__(self, shapelist):
        self.shapelist = shapelist

    def rotate(self):
        list_of_tuples = zip(*self.shapelist[::-1])
        rotatedShape = [list(i) for i in list_of_tuples]
        self.shapelist = rotatedShape
    def drawtempShape(self,row,col):
        for i in range(len(self.shapelist)):
            for j in range(len(self.shapelist[0])):
                if self.shapelist[i][j]:
                    drawTempRect(row-j,col-i)
                    
    def addShape(self,row,col):
        for i in range(len(self.shapelist)):
            for j in range(len(self.shapelist[0])):
                if self.shapelist[i][j]:
                    giveLife(row-j,col-i)

# Preset Shape Tuples #
smallglider = Shape([[False,True,False],
                     [False,False,True],
                     [True,True,True]])

smallexploder = Shape([[False,True,False],
                       [True,True,True],
                       [True,False,True],
                       [False,True,False]])

spaceship = Shape([[False,True,True,True,True],
                   [True,False,False,False,True],
                   [False,False,False,False,True],
                   [True,False,False,True,False]])

tumbler = Shape([[False,True,True,False,True,True,False],
                 [False,True,True,False,True,True,False],
                 [False,False,True,False,True,False,False],
                 [True,False,True,False,True,False,True],
                 [True,False,True,False,True,False,True],
                 [True,True,False,False,False,True,True]])

# Preset Shape List #       
allShapes = [smallglider, smallexploder, spaceship, tumbler]

# Activate a Grid Cell #
def giveLife(row, col):
    board[row][col] = True
